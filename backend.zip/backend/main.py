
from pathlib import Path
from uuid import uuid4
import mimetypes

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles


# ============================================
# 1. CREATE FASTAPI APPLICATION
# ============================================

app = FastAPI(
    title="BrandPilot AI",
    description="AI Instagram Manager and Security Guardian",
    version="1.0.0"
)


# ============================================
# 2. FRONTEND CORS CONFIGURATION
# ============================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


# ============================================
# 3. FILE UPLOAD CONFIGURATION
# ============================================

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Make uploaded files accessible for local demo
app.mount(
    "/uploads",
    StaticFiles(directory=str(UPLOAD_DIR)),
    name="uploads"
)

ALLOWED_TYPES = {
    "image/jpeg": (".jpg", "image"),
    "image/png": (".png", "image"),
    "image/webp": (".webp", "image"),
    "video/mp4": (".mp4", "video"),
    "video/quicktime": (".mov", "video")
}

MAX_FILE_SIZE = 50 * 1024 * 1024
MAX_FILES = 5


# ============================================
# 4. HOME ENDPOINT
# ============================================

@app.get("/")
def home():
    return {
        "message": "Welcome to BrandPilot AI!",
        "status": "Backend is running successfully"
    }


# ============================================
# 5. HEALTH CHECK ENDPOINT
# ============================================

@app.get("/api/v1/health")
def health_check():
    return {
        "status": "healthy",
        "service": "BrandPilot AI Backend",
        "version": "1.0.0"
    }


# ============================================
# 6. MEDIA UPLOAD ENDPOINT
# ============================================

@app.post("/api/v1/media/upload")
async def upload_media(
    files: list[UploadFile] = File(...)
):
    """
    Upload images and videos for Instagram content.

    Supported:
    JPG, PNG, WEBP, MP4, MOV

    Maximum:
    5 files per request
    50 MB per file
    """

    if len(files) > MAX_FILES:
        raise HTTPException(
            status_code=400,
            detail="Maximum 5 files are allowed."
        )

    uploaded_assets = []

    for file in files:

        # Validate media type
        if file.content_type not in ALLOWED_TYPES:
            raise HTTPException(
                status_code=415,
                detail=(
                    f"Unsupported file type: {file.content_type}. "
                    "Allowed: JPG, PNG, WEBP, MP4, MOV."
                )
            )

        extension, media_type = ALLOWED_TYPES[file.content_type]

        file_id = str(uuid4())
        saved_filename = f"{file_id}{extension}"
        file_path = UPLOAD_DIR / saved_filename

        total_size = 0

        try:
            with open(file_path, "wb") as output:

                while True:
                    chunk = await file.read(1024 * 1024)

                    if not chunk:
                        break

                    total_size += len(chunk)

                    if total_size > MAX_FILE_SIZE:
                        raise HTTPException(
                            status_code=413,
                            detail=(
                                f"File '{file.filename}' "
                                "exceeds the 50 MB limit."
                            )
                        )

                    output.write(chunk)

        except Exception:
            file_path.unlink(missing_ok=True)
            raise

        finally:
            await file.close()

        uploaded_assets.append({
            "id": file_id,
            "filename": file.filename,
            "media_type": media_type,
            "url": (
                f"http://127.0.0.1:8000/uploads/"
                f"{saved_filename}"
            ),
            "mime_type": file.content_type,
            "size_bytes": total_size
        })

    return {
        "assets": uploaded_assets
    }
